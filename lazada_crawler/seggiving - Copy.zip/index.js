const TikiCrawler = require('./src/crawlers/tiki');
const LazadaCrawler = require('./src/crawlers/lazada');
const { testConnection } = require('./src/utils/db');
require('dotenv').config();

async function main() {
  const fs = require('fs');
  const path = require('path');

  console.log('🔌 Kiểm tra kết nối database...\n');
  const dbOk = await testConnection();

  if (!dbOk) {
    console.error('❌ Không kết nối được database!');
    process.exit(1);
  }

  // ===== ĐỌC CONFIG =====
  let config;
  try {
    const configPath = path.join(__dirname, 'config.json');
    config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    console.log('✅ Đọc config thành công!\n');
  } catch (error) {
    console.error('❌ Không đọc được file config.json:', error.message);
    process.exit(1);
  }

  // ===== ĐỌC/TẠO PROGRESS =====
  const progressPath = path.join(__dirname, 'progress.json');
  let progress;

  try {
    progress = JSON.parse(fs.readFileSync(progressPath, 'utf8'));
    console.log('✅ Đọc progress thành công!\n');
  } catch (error) {
    // Tạo progress mới từ config
    console.log('📝 Tạo progress mới từ config...\n');
    progress = {
      keywords: config.keywords.map(k => ({
        term: k,
        status: 'pending',
        completedAt: null
      }))
    };
    fs.writeFileSync(progressPath, JSON.stringify(progress, null, 2));
  }

  // ===== TÌM KEYWORD TIẾP THEO =====
  const nextTask = progress.keywords.find(k => k.status === 'pending');

  if (!nextTask) {
    console.log('✅ ĐÃ HOÀN THÀNH TẤT CẢ KEYWORDS!');
    console.log('💡 Để chạy lại, dùng: node reset_progress.js\n');
    process.exit(0);
  }

  const currentIndex = progress.keywords.indexOf(nextTask);
  const keyword = nextTask.term;

  console.log(`${'='.repeat(60)}`);
  console.log(`🔍 [${currentIndex + 1}/${progress.keywords.length}] Từ khóa: "${keyword}"`);
  console.log(`${'='.repeat(60)}\n`);

  // ===== KHỞI TẠO CRAWLER =====
  let crawler;
  if (config.platform === '2') {
    crawler = new LazadaCrawler();
    console.log('🛒 Sàn: Lazada');
  } else {
    crawler = new TikiCrawler();
    console.log('🛒 Sàn: Tiki');
  }

  await crawler.init();
  console.log(`📄 Max pages: ${config.maxPages}\n`);

  // ===== TẠO URL =====
  const encoded = encodeURIComponent(keyword);
  let categoryUrl;
  if (config.platform === '2') {
    categoryUrl = `https://www.lazada.vn/catalog/?q=${encoded}`;
  } else {
    categoryUrl = `https://tiki.vn/search?q=${encoded}`;
  }

  // ===== CRAWL KEYWORD NÀY =====
  let keywordTotalNew = 0;

  for (let page = 1; page <= config.maxPages; page++) {
    const result = await crawler.crawlListingPage(categoryUrl, keyword, page);
    keywordTotalNew += result.new;

    // Auto-stop nếu không còn sản phẩm
    if (result.total === 0) {
      console.log(`\n⚠️ Trang ${page} không còn sản phẩm. Dừng crawl keyword này!`);
      break;
    }

    // Delay giữa các trang
    if (page < config.maxPages) {
      console.log('⏳ Đợi 5 giây...\n');
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }

  await crawler.close();

  console.log(`\n✅ Hoàn thành "${keyword}": ${keywordTotalNew} sản phẩm mới\n`);

  // ===== CẬP NHẬT PROGRESS =====
  nextTask.status = 'completed';
  nextTask.completedAt = new Date().toISOString();
  fs.writeFileSync(progressPath, JSON.stringify(progress, null, 2));
  console.log('💾 Đã lưu progress\n');

  // ===== KIỂM TRA CÒN KEYWORD NÀO KHÔNG =====
  const remaining = progress.keywords.filter(k => k.status === 'pending').length;

  if (remaining > 0) {
    // Random delay 1-3 phút
    const delayMinutes = Math.floor(Math.random() * 3) + 1;
    const delayMs = delayMinutes * 60 * 1000;

    console.log(`📊 Còn ${remaining} keyword chưa crawl`);
    console.log(`⏳ Đợi ${delayMinutes} phút trước khi restart...\n`);

    await new Promise(resolve => setTimeout(resolve, delayMs));

    console.log('🔄 Tắt process để restart...\n');
    process.exit(0);
  } else {
    console.log('🎉 ĐÃ HOÀN THÀNH TẤT CẢ KEYWORDS!\n');
    process.exit(0);
  }
}

main();